let date=(date)=>{
    let year=date.split(".")[2]
    let month=date.split(".")[1]
    let day=date.split(".")[0]
    return new Date(year+"-"+month+"-" + day+ "T16:00:00Z");
}


let AUTHOR_1 = db.Authors.insertOne({first_name: "Евгений", last_name: "Замятин", patronymic: "Иванович",
                                     birth_date: new Date('1884-02-01'), death_date: new Date('1937-03-10')});

let AUTHOR_2 = db.Authors.insertOne({first_name: "Александр", last_name: "Пушкин", patronymic: "Сергеевич",
                                     birth_date: new Date('1799-05-26'), death_date: new Date('1837-01-29')});

let AUTHOR_3 = db.Authors.insertOne({first_name: "Марина", last_name: "Цветаева", patronymic: "Ивановна",
                                     birth_date: new Date('1892-10-08'), death_date: new Date('1941-08-31')});

let AUTHOR_4 = db.Authors.insertOne({first_name: "Константин", last_name: "Иванов", patronymic: "Раисович",
                                     birth_date: new Date('1960-10-08'), death_date: null});

let AUTHOR_5 = db.Authors.insertOne({first_name: "Марина", last_name: "Керч", patronymic: "Николаевна",
                                     birth_date: new Date('1975-11-02'), death_date: null});

let AUTHOR_6 = db.Authors.insertOne({first_name: "Александр", last_name: "Солженицын", patronymic: "Исаевич",
                                     birth_date: new Date('1918-12-11'), death_date: new Date('2008-08-03')});


let FUND_ITEM_1 = db.FundItems.insertOne({item_number: 125473});
let FUND_ITEM_2 = db.FundItems.insertOne({item_number: 652434});
let FUND_ITEM_3 = db.FundItems.insertOne({item_number: 45757});
let FUND_ITEM_4 = db.FundItems.insertOne({item_number: 886777});
let FUND_ITEM_5 = db.FundItems.insertOne({item_number: 7218});
let FUND_ITEM_6 = db.FundItems.insertOne({item_number: 2148});
let FUND_ITEM_7 = db.FundItems.insertOne({item_number: 9632});
let FUND_ITEM_8 = db.FundItems.insertOne({item_number: 24813794});
let FUND_ITEM_9 = db.FundItems.insertOne({item_number: 231284});
let FUND_ITEM_10 = db.FundItems.insertOne({item_number: 321587});
let FUND_ITEM_11 = db.FundItems.insertOne({item_number: 125934});
let FUND_ITEM_12 = db.FundItems.insertOne({item_number: 61527});
let FUND_ITEM_13 = db.FundItems.insertOne({item_number: 13});
let FUND_ITEM_14 = db.FundItems.insertOne({item_number: 8437});
let FUND_ITEM_15 = db.FundItems.insertOne({item_number: 213452417});
let FUND_ITEM_16 = db.FundItems.insertOne({item_number: 3462781});
let FUND_ITEM_17 = db.FundItems.insertOne({item_number: 32492715});
let FUND_ITEM_18 = db.FundItems.insertOne({item_number: 312842});
let FUND_ITEM_19 = db.FundItems.insertOne({item_number: 196});
let FUND_ITEM_20 = db.FundItems.insertOne({item_number: 32417});


let PUBLICATION_1 = db.Publications.insertOne({name: "Мы", pages: 352, p_year: new Date('2000-01-01'),
                                               authors: [AUTHOR_1.insertedId],
                                               items: [FUND_ITEM_1.insertedId, FUND_ITEM_2.insertedId],
                                               category: "Роман",
                                               attributes: {genre: "Антиутопия"},
                                               receipt_date: new Date('2000-09-18')});

let PUBLICATION_2 = db.Publications.insertOne({name: "Капитанская дочка", pages: 215, p_year: new Date('1994-01-01'),
                                               authors: [AUTHOR_2.insertedId],
                                               items: [FUND_ITEM_3.insertedId],
                                               category: "Роман",
                                               attributes: {genre: "Исторический"},
                                               receipt_date: new Date('2001-02-10')});

let PUBLICATION_3 = db.Publications.insertOne({name: "Поэмы и стихи", pages: 127, p_year: new Date('2005-01-01'),
                                               authors: [AUTHOR_2.insertedId],
                                               items: [FUND_ITEM_10.insertedId, FUND_ITEM_11.insertedId],
                                               category: "Коллекция поэм",
                                               attributes: {kind: "Вольный", meter: "Ямб"},
                                               receipt_date: new Date('2006-04-27')});

let PUBLICATION_4 = db.Publications.insertOne({name: "Избранные поэмы", pages: 165, p_year: new Date('2004-01-01'),
                                               authors: [AUTHOR_3.insertedId],
                                               items: [FUND_ITEM_4.insertedId, FUND_ITEM_12.insertedId, FUND_ITEM_13.insertedId],
                                               category: "Коллекция поэм",
                                               attributes: {kind: "Смешанный", meter: "Ямб"},
                                               receipt_date: new Date('2006-04-27')});
                                               
let PUBLICATION_5 = db.Publications.insertOne({name: "Стихи", pages: 120, p_year: new Date('2006-01-01'),
                                               authors: [AUTHOR_3.insertedId],
                                               items: [FUND_ITEM_14.insertedId],
                                               category: "Коллекция поэм",
                                               attributes: {kind: "Вольный", meter: "Хорей"},
                                               receipt_date: new Date('2007-03-19')});

let PUBLICATION_6 = db.Publications.insertOne({name: "Органическая химия", pages: 20, p_year: new Date('2010-01-01'),
                                               authors: [AUTHOR_4.insertedId, AUTHOR_5.insertedId],
                                               items: [FUND_ITEM_15.insertedId],
                                               category: "Статья",
                                               attributes: {field: "Химия"},
                                               receipt_date: new Date('2010-04-04')});

let PUBLICATION_7 = db.Publications.insertOne({name: "Анатомия человека", pages: 32, p_year: new Date('2009-01-01'),
                                               authors: [AUTHOR_4.insertedId],
                                               items: [FUND_ITEM_9.insertedId, FUND_ITEM_16.insertedId],
                                               category: "Статья",
                                               attributes: {field: "Биология"},
                                               receipt_date: new Date('2010-04-04')});

let PUBLICATION_8 = db.Publications.insertOne({name: "Химия твердого тела", pages: 32, p_year: new Date('2010-01-01'),
                                               authors: [AUTHOR_5.insertedId],
                                               items: [FUND_ITEM_5.insertedId, FUND_ITEM_8.insertedId, FUND_ITEM_17.insertedId],
                                               category: "Статья",
                                               attributes: {field: "Химия"},
                                               receipt_date: new Date('2010-07-02')});
                                               
let PUBLICATION_9 = db.Publications.insertOne({name: "Один день Ивана Денисовича", pages: 130, p_year: new Date('2008-01-01'),
                                               authors: [AUTHOR_6.insertedId],
                                               items: [FUND_ITEM_6.insertedId, FUND_ITEM_18.insertedId],
                                               category: "Рассказ",
                                               attributes: {genre: "Исторический"},
                                               receipt_date: new Date('2009-11-07')});

let PUBLICATION_10 = db.Publications.insertOne({name: "Матренин двор", pages: 130, p_year: new Date('2009-01-01'),
                                                authors: [AUTHOR_6.insertedId],
                                                items: [FUND_ITEM_7.insertedId, FUND_ITEM_19.insertedId, FUND_ITEM_20.insertedId],
                                                category: "Рассказ",
                                                attributes: {genre: "Бытовой"},
                                                receipt_date: new Date('2011-06-25')});


let SHELF_1 = db.Shelfs.insertOne({items: [FUND_ITEM_1.insertedId, FUND_ITEM_2.insertedId, FUND_ITEM_3.insertedId]});
let SHELF_2 = db.Shelfs.insertOne({items: []});
let SHELF_3 = db.Shelfs.insertOne({items: [FUND_ITEM_4.insertedId]});
let SHELF_4 = db.Shelfs.insertOne({items: [FUND_ITEM_5.insertedId, FUND_ITEM_6.insertedId]});
let SHELF_5 = db.Shelfs.insertOne({items: [FUND_ITEM_7.insertedId]});
let SHELF_6 = db.Shelfs.insertOne({items: [FUND_ITEM_9.insertedId, FUND_ITEM_10.insertedId]});
let SHELF_7 = db.Shelfs.insertOne({items: [FUND_ITEM_8.insertedId]});
let SHELF_8 = db.Shelfs.insertOne({items: []});
let SHELF_9 = db.Shelfs.insertOne({items: [FUND_ITEM_11.insertedId, FUND_ITEM_12.insertedId, FUND_ITEM_16.insertedId, FUND_ITEM_17.insertedId, FUND_ITEM_20.insertedId]});
let SHELF_10 = db.Shelfs.insertOne({items: [FUND_ITEM_13.insertedId, FUND_ITEM_14.insertedId, FUND_ITEM_15.insertedId, FUND_ITEM_18.insertedId, FUND_ITEM_19.insertedId]});

                                                
let RACK_1 = db.Racks.insertOne({shelfs: [SHELF_1.insertedId, SHELF_2.insertedId]});
let RACK_2 = db.Racks.insertOne({shelfs: [SHELF_3.insertedId, SHELF_4.insertedId]});
let RACK_3 = db.Racks.insertOne({shelfs: [SHELF_5.insertedId, SHELF_6.insertedId]});
let RACK_4 = db.Racks.insertOne({shelfs: [SHELF_7.insertedId, SHELF_8.insertedId]});
let RACK_5 = db.Racks.insertOne({shelfs: [SHELF_9.insertedId, SHELF_10.insertedId]});


let STORAGE_1 = db.Storages.insertOne({racks: [RACK_1.insertedId]});
let STORAGE_2 = db.Storages.insertOne({racks: [RACK_2.insertedId]});
let STORAGE_3 = db.Storages.insertOne({racks: [RACK_3.insertedId, RACK_4.insertedId]});
let STORAGE_4 = db.Storages.insertOne({racks: [RACK_5.insertedId]});


let LIBRARIAN_1 = db.Librarians.insertOne({first_name: "Алиса", last_name: "Лира", patronymic: null,
                                           device_date: new Date('2014-06-11'), dismissal_date: null});

let LIBRARIAN_2 = db.Librarians.insertOne({first_name: "Дарья", last_name: "Симонова", patronymic: "Георгиевна",
                                           device_date: new Date('2010-11-01'), dismissal_date: new Date('2014-08-11')});

let LIBRARIAN_3 = db.Librarians.insertOne({first_name: "Николай", last_name: "Ринов", patronymic: "Алексеевич",
                                           device_date: new Date('2015-07-15'), dismissal_date: null});

let LIBRARIAN_4 = db.Librarians.insertOne({first_name: "Татьяна", last_name: "Ринова", patronymic: "Дмитриевна",
                                           device_date: new Date('2013-01-10'), dismissal_date: null});

let LIBRARIAN_5 = db.Librarians.insertOne({first_name: "Дарья", last_name: "Килман", patronymic: "Николаевна",
                                           device_date: new Date('2017-08-20'), dismissal_date: null});


let READING_ROOM_1 = db.ReadingRooms.insertOne({places: 100, librarians: [LIBRARIAN_1.insertedId, LIBRARIAN_2.insertedId],
                                               items: [FUND_ITEM_1.insertedId, FUND_ITEM_2.insertedId, FUND_ITEM_3.insertedId, FUND_ITEM_4.insertedId, FUND_ITEM_5.insertedId, FUND_ITEM_6.insertedId]});

let READING_ROOM_2 = db.ReadingRooms.insertOne({places: 50, librarians: [LIBRARIAN_3.insertedId],
                                                items: [FUND_ITEM_7.insertedId]});

let READING_ROOM_3 = db.ReadingRooms.insertOne({places: 20, librarians: [LIBRARIAN_4.insertedId],
                                                items: [FUND_ITEM_8.insertedId, FUND_ITEM_9.insertedId, FUND_ITEM_10.insertedId]});

let READING_ROOM_4 = db.ReadingRooms.insertOne({places: 70, librarians: [LIBRARIAN_5.insertedId],
                                                items: [FUND_ITEM_11.insertedId, FUND_ITEM_12.insertedId, FUND_ITEM_13.insertedId, FUND_ITEM_14.insertedId, FUND_ITEM_15.insertedId, FUND_ITEM_16.insertedId, FUND_ITEM_17.insertedId, FUND_ITEM_18.insertedId, FUND_ITEM_19.insertedId, FUND_ITEM_20.insertedId]});


let LIBRARY_CARD_1 = db.LibraryCards.insertOne({
    first_name: "Эдвард",
    last_name: "Элрик",
    birth_date: new Date('2001-10-20'),
    address: " ",
    phone: " ",
    registration_date: new Date('2013-07-10'),
    category: "Студент",
    attributes: {
        university: "КемГУ",
        department: "Химия"
    },
    rows: [
        {
            librarian: LIBRARIAN_1.insertedId,
            item: FUND_ITEM_4.insertedId,
            issue_date: date('04.08.2020'),
            deadline_date: date('24.08.2020'),
            return_date: date('20.08.2020')
        },
        {
            librarian: LIBRARIAN_1.insertedId,
            item: FUND_ITEM_6.insertedId,
            issue_date: date('04.08.2020'),
            deadline_date: date('24.08.2020'),
            return_date: date('15.08.2020')
        },
        {
            librarian: LIBRARIAN_1.insertedId,
            item: FUND_ITEM_3.insertedId,
            issue_date: date('01.01.2021'),
            deadline_date: date('21.01.2021'),
            return_date: date('20.01.2021')
        },
        {
            librarian: LIBRARIAN_1.insertedId,
            item: FUND_ITEM_1.insertedId,
            issue_date: date('03.01.2021'),
            deadline_date: date('23.01.2021'),
            return_date: date('23.01.2021')
        },
    ]
});

let LIBRARY_CARD_2 = db.LibraryCards.insertOne({
    first_name: "Альфонс",
    last_name: "Элрик",
    birth_date: new Date('2001-09-16'),
    address: " ",
    phone: " ",
    registration_date: new Date('2014-09-15'),
    category: "Студент",
    attributes: {
        university: "КемГУ",
        department: "Химия"
    },
    rows: [
        {
            librarian: LIBRARIAN_1.insertedId,
            item: FUND_ITEM_2.insertedId,
            issue_date: date('02.06.2021'),
            deadline_date: date('22.06.2021'),
            return_date: null
        }
    ]
});

let LIBRARY_CARD_3 = db.LibraryCards.insertOne({
    first_name: "Изуми",
    last_name: "Кертис",
    birth_date: new Date('2002-06-02'),
    address: " ",
    phone: " ",
    registration_date: new Date('2014-12-23'),
    category: "Студент",
    attributes: {
        university: "КузГТУ",
        department: "Физика"
    },
    rows: []
});

let LIBRARY_CARD_4 = db.LibraryCards.insertOne({
    first_name: "Линг",
    last_name: "Яо",
    birth_date: new Date('2002-07-13'),
    address: " ",
    phone: " ",
    registration_date: new Date('2015-05-01'),
    category: "Студент",
    attributes: {
        university: "КузГТУ",
        department: "Химия"
    },
    rows: []
});

let LIBRARY_CARD_5 = db.LibraryCards.insertOne({
    first_name: "Риза",
    last_name: "Хоукай",
    birth_date: new Date('1995-11-01'),
    address: " ",
    phone: " ",
    registration_date: new Date('2016-11-26'),
    category: "Работник",
    attributes: {
        company: "КемГУ"
    },
    rows: [
        {
            librarian: LIBRARIAN_3.insertedId,
            item: FUND_ITEM_7.insertedId,
            issue_date: date('05.09.2020'),
            deadline_date: date('25.09.2020'),
            return_date: date('12.09.2020')
        }
    ]
});

let LIBRARY_CARD_6 = db.LibraryCards.insertOne({
    first_name: "Рой",
    last_name: "Мустанг",
    birth_date: new Date('1994-10-06'),
    address: " ",
    phone: " ",
    registration_date: new Date('2014-07-15'),
    category: "Работник",
    attributes: {
        company: "ООО СИНКИ"
    },
    rows: [
        {
            librarian: LIBRARIAN_4.insertedId,
            item: FUND_ITEM_8.insertedId,
            issue_date: date('01.09.2020'),
            deadline_date: date('21.09.2020'),
            return_date: date('27.09.2020')
        }
    ]
});

let LIBRARY_CARD_7 = db.LibraryCards.insertOne({
    first_name: "Сателла",
    last_name: "ЛеКольт",
    birth_date: new Date('1992-12-09'),
    address: " ",
    phone: " ",
    registration_date: new Date('2014-11-24'),
    category: "Работник",
    attributes: {
        company: "КузГТУ"
    },
    rows: [
        {
            librarian: LIBRARIAN_4.insertedId,
            item: FUND_ITEM_10.insertedId,
            issue_date: date('01.09.2020'),
            deadline_date: date('21.09.2020'),
            return_date: date('21.09.2020')
        }
    ]
});

let LIBRARY_CARD_8 = db.LibraryCards.insertOne({
    first_name: "Селим",
    last_name: "Бредли",
    birth_date: date('11.01.1990'),
    address: " ",
    phone: " ",
    registration_date: new Date('2015-10-20'),
    category: "Работник",
    attributes: {
        company: "ООО СИНКИ"
    },
    rows: []
});

let LIBRARY_CARD_9 = db.LibraryCards.insertOne({
    first_name: "Уинри",
    last_name: "Рокбелл",
    birth_date: date('26.05.1985'),
    address: " ",
    phone: " ",
    registration_date: new Date('2019-12-03'),
    category: "Работник",
    attributes: {
        company: "ОАО РЕНТА"
    },
    rows: []
});

let LIBRARY_CARD_10 = db.LibraryCards.insertOne({
    first_name: "Денни",
    last_name: "Брош",
    birth_date: date('29.09.1960'),
    address: " ",
    phone: " ",
    registration_date: new Date('2020-03-28'),
    category: "Пенсионер",
    attributes: {},
    rows: [
        {
            librarian: LIBRARIAN_4.insertedId,
            item: FUND_ITEM_10.insertedId,
            issue_date: date('03.10.2020'),
            deadline_date: date('23.10.2020'),
            return_date: date('29.10.2020')
        },
        {
            librarian: LIBRARIAN_5.insertedId,
            item: FUND_ITEM_20.insertedId,
            issue_date: date('07.10.2020'),
            deadline_date: date('27.10.2020'),
            return_date: date('26.10.2020')
        }
    ]
});

let LIBRARY_CARD_11 = db.LibraryCards.insertOne({
    first_name: "Элисия",
    last_name: "Хьюз",
    birth_date: date('03.07.1955'),
    address: " ",
    phone: " ",
    registration_date: new Date('2015-07-11'),
    category: "Пенсионер",
    attributes: {},
    rows: [
        {
            librarian: LIBRARIAN_5.insertedId,
            item: FUND_ITEM_19.insertedId,
            issue_date: date('07.10.2020'),
            deadline_date: date('27.10.2020'),
            return_date: date('11.11.2020')
        }
    ]
});

let LIBRARY_CARD_12 = db.LibraryCards.insertOne({
    first_name: "Лан",
    last_name: "Фан",
    birth_date: date('16.03.1965'),
    address: " ",
    phone: " ",
    registration_date: new Date('2016-09-19'),
    category: "Пенсионер",
    attributes: {},
    rows: [
        {
            librarian: LIBRARIAN_1.insertedId,
            item: FUND_ITEM_1.insertedId,
            issue_date: date('07.10.2020'),
            deadline_date: date('27.10.2020'),
            return_date: date('20.10.2020')
        }
    ]
});

let LIBRARY_CARD_13 = db.LibraryCards.insertOne({
    first_name: "Маэс",
    last_name: "Хьюз",
    birth_date: date('17.02.1961'),
    address: " ",
    phone: " ",
    registration_date: new Date('2019-08-16'),
    category: "Пенсионер",
    attributes: {},
    rows: [
        {
            librarian: LIBRARIAN_1.insertedId,
            item: FUND_ITEM_1.insertedId,
            issue_date: date('08.11.2020'),
            deadline_date: date('28.11.2020'),
            return_date: null
        }
    ]
});

let LIBRARY_CARD_14 = db.LibraryCards.insertOne({
    first_name: "Мария",
    last_name: "Росс",
    birth_date: date('18.01.2010'),
    address: " ",
    phone: " ",
    registration_date: new Date('2019-08-16'),
    category: "Школьник",
    attributes: {
        school: 11
    },
    rows: [
        {
            librarian: LIBRARIAN_1.insertedId,
            item: FUND_ITEM_2.insertedId,
            issue_date: date('05.11.2020'),
            deadline_date: date('25.11.2020'),
            return_date: date('24.11.2020')
        }
    ]
});

let LIBRARY_CARD_15 = db.LibraryCards.insertOne({
    first_name: "Ребекка",
    last_name: "Каталина",
    birth_date: date('12.12.2011'),
    address: " ",
    phone: " ",
    registration_date: new Date('2020-05-29'),
    category: "Школьник",
    attributes: {
        school: 19
    },
    rows: [
        {
            librarian: LIBRARIAN_4.insertedId,
            item: FUND_ITEM_9.insertedId,
            issue_date: date('05.11.2020'),
            deadline_date: date('25.11.2020'),
            return_date: date('14.11.2020')
        }
    ]
});

let LIBRARY_1 = db.Libraries.insertOne({address: "Улица Аниме, 21",
                                        storages: [STORAGE_1.insertedId, STORAGE_2.insertedId],
                                        reading_rooms:[READING_ROOM_1.insertedId],
                                        cards: [LIBRARY_CARD_1.insertedId, LIBRARY_CARD_2.insertedId, LIBRARY_CARD_3.insertedId, LIBRARY_CARD_4.insertedId, LIBRARY_CARD_5.insertedId]});
let LIBRARY_2 = db.Libraries.insertOne({address: "Улица Красная, 13",
                                        storages: [STORAGE_3.insertedId],
                                        reading_rooms:[READING_ROOM_2.insertedId, READING_ROOM_3.insertedId],
                                        cards: [LIBRARY_CARD_6.insertedId, LIBRARY_CARD_7.insertedId, LIBRARY_CARD_8.insertedId, LIBRARY_CARD_9.insertedId, LIBRARY_CARD_10.insertedId]});
let LIBRARY_3 = db.Libraries.insertOne({address: "Улица Квадратная, 7",
                                        storages: [STORAGE_4.insertedId],
                                        reading_rooms:[READING_ROOM_4.insertedId],
                                        cards: [LIBRARY_CARD_11.insertedId, LIBRARY_CARD_12.insertedId, LIBRARY_CARD_13.insertedId, LIBRARY_CARD_14.insertedId, LIBRARY_CARD_15.insertedId]});
