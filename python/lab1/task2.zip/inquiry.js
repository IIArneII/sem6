//1
db.LibraryCards.find({
    category: "Студент",
    "attributes.university": "КемГУ"
},
{
    _id: 0,
    first_name: 1,
    last_name: 1,
    category: 1,
    "attributes.university": 1
});

//2
db.LibraryCards.aggregate([
    {$unwind: "$rows"},
    {$lookup:{
		from: "Publications",
		localField: "rows.item",
		foreignField: "items",
		as: "rows.item"
	}},
    {$match:{
        "rows.item.name": "Мы",
        "rows.return_date": null
    }},
    {$group:{
		_id: "$rows.item",
        readers: {$addToSet: {first_name: "$first_name", last_name: "$last_name"}}
	}},
    {$project: {
        _id: 0,
        name: {$arrayElemAt: ["$_id.name", 0]},
        readers: 1
    }}
]);

//3
db.LibraryCards.aggregate([
    {$unwind: "$rows"},
    {$lookup:{
		from: "Publications",
		localField: "rows.item",
		foreignField: "items",
		as: "rows.item"
	}},
    {$match:{
        "rows.item.category": "Роман",
        "rows.return_date": null
    }},
    {$group:{
		_id: "$rows.item.category",
        readers: {$addToSet: {first_name: "$first_name", last_name: "$last_name"}}
	}},
    {$project: {
        _id: 0,
        name: {$arrayElemAt: ["$_id", 0]},
        readers: 1
    }}
]);

//4
db.LibraryCards.aggregate([
    {$unwind: "$rows"},
    {$lookup:{
		from: "Publications",
		localField: "rows.item",
		foreignField: "items",
		as: "rows.item"
	}},
    {$match:{
        $and:[
            {"rows.issue_date": {$gte: new Date("2020-10-01")}},
            {"rows.issue_date": {$lte: new Date("2020-11-01")}}
        ]
    }},
    {$group:{
		_id: {_id: "$_id", first_name: "$first_name", last_name: "$last_name"},
        items: {$addToSet: {$arrayElemAt: ["$rows.item.name", 0]}}
	}},
    {$project: {
        _id: 0,
        first_name: "$_id.first_name",
        last_name: "$_id.last_name",
        items: "$items"
    }}
]);

//5
db.LibraryCards.aggregate([
    {$unwind: "$rows"},
    {$match:{
        first_name: "Эдвард",
        last_name: "Элрик",
        $and:[
            {"rows.issue_date": {$gte: new Date("2020-08-04")}},
            {"rows.issue_date": {$lte: new Date("2021-01-02")}}
        ]
    }},
    {$lookup:{
		from: "ReadingRooms",
		localField: "rows.librarian",
		foreignField: "librarians",
		as: "rows.reading_room"
	}},
    {$lookup:{ //Библиотека, в которой брал очередную книгу
		from: "Libraries",
		localField: "rows.reading_room._id",
		foreignField: "reading_rooms",
		as: "rows.library"
	}},
    {$lookup:{ //Библиотека, в которой зарегистрирован
		from: "Libraries",
		localField: "_id",
		foreignField: "cards",
		as: "library"
	}},
    {$match: { //Сравниваем ту, где зарегистрирован и ту, где брал книгу
        $expr: {$eq: ["$library._id", "$rows.library._id"]}
    }},
    {$lookup:{
		from: "Publications",
		localField: "rows.item",
		foreignField: "items",
		as: "rows.item"
	}},
    {$group:{
		_id: null,
        items: {$addToSet: {$arrayElemAt: ["$rows.item.name", 0]}}
	}},
    {$project:{
        _id: 0,
        items: 1
    }}
]);

//6
db.LibraryCards.aggregate([
    {$unwind: "$rows"},
    {$match:{
        first_name: "Риза",
        last_name: "Хоукай",
        $and:[
            {"rows.issue_date": {$gte: new Date("2020-09-01")}},
            {"rows.issue_date": {$lte: new Date("2021-01-01")}}
        ]
    }},
    {$lookup:{
		from: "ReadingRooms",
		localField: "rows.librarian",
		foreignField: "librarians",
		as: "rows.reading_room"
	}},
    {$lookup:{ //Библиотека, в которой брала очередную книгу
		from: "Libraries",
		localField: "rows.reading_room._id",
		foreignField: "reading_rooms",
		as: "rows.library"
	}},
    {$lookup:{ //Библиотека, в которой зарегистрирована
		from: "Libraries",
		localField: "_id",
		foreignField: "cards",
		as: "library"
	}},
    {$match:{ //Сравниваем ту, где зарегистрирована и ту, где брала книгу
        $expr: {$ne: ["$library._id", "$rows.library._id"]}
    }},
    {$lookup:{
		from: "Publications",
		localField: "rows.item",
		foreignField: "items",
		as: "rows.item"
	}},
    {$group:{
		_id: null,
        items: {$addToSet: {$arrayElemAt: ["$rows.item.name", 0]}}
	}},
    {$project:{
        _id: 0,
        items: 1
    }}
]);

//7
db.Shelfs.aggregate([
    {$limit: 1},
    {$unwind: "$items"},
    {$lookup:{
		from: "Publications",
		localField: "items",
		foreignField: "items",
		as: "publication"
	}},
    {$lookup:{
		from: "LibraryCards",
		localField: "items",
		foreignField: "rows.item",
		as: "cards"
	}},
    {$match:{
        "cards.rows.return_date": null
    }},
    {$project:{
        publication: "$publication.name"
    }}
]);

//8
db.LibraryCards.aggregate([
    {$match:{
        "rows.return_date": null,
        "rows.deadline_date": {$lt: new Date()}
    }},
    {$group:{
		_id: null,
        readers: {$addToSet: {first_name: "$first_name", last_name: "$last_name", }}
	}},
    {$project:{
        _id: 0,
        readers: 1
    }}
]);

//9
db.Publications.aggregate([
    {$match:{
        $and:[
            {receipt_date: {$gte: new Date('2009-01-01')}},
            {receipt_date: {$lte: new Date('2011-01-01')}}
        ]
    }},
    {$project:{
        _id: 0,
        receipt_date: 1,
        name: 1
    }}
]);

//10
db.ReadingRooms.aggregate([
    {$limit: 1},
    {$unwind: "$librarians"},
    {$lookup:{
		from: "Librarians",
		localField: "librarians",
		foreignField: "_id",
		as: "librarians"
	}},
    {$match:{
        "librarians.dismissal_date": null
    }},
    {$project:{
        _id: 0,
        first_name: {$arrayElemAt: ["$librarians.first_name", 0]},
        last_name: {$arrayElemAt: ["$librarians.last_name", 0]}
    }}
]);
